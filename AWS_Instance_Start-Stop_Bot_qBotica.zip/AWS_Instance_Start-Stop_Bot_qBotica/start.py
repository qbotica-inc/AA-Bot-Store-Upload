import xlrd
import boto3
file_location = r'C:\Users\Admin\Desktop\stop\start.xlsx'
workbook = xlrd.open_workbook(file_location)
sheet = workbook.sheet_by_index(0)
i=2
while i<5:
 out = sheet.cell_value(i, 3)
 print(out)
 ec2 = boto3.resource('ec2')
 ids = [out]
 ec2.instances.filter(InstanceIds=ids).start()
 i +=1
